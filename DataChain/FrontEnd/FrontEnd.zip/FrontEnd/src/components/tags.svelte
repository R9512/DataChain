<script>
    export let tagname
</script>
<div class="tags" id ="temp">#{tagname}</div>
<style>
        .tags {
  background-color: #ddd;
  border: none;
  color: black;
  padding: 10px 20px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  margin: 4px 2px;
  cursor: pointer;
  border-radius: 16px;
}
</style>