<script>

    import 'boxicons'
    export let icon=""
    export let name=""
    export let text = ""
    export let value=""
    export let color=""
</script>
<div class="card">
    <div style="padding: 12px;">
<span style="font-size:23px;color:#939aa5">{name}</span>
<span class="dot" style="background-color:{color}"><center><box-icon name={icon} type = "logo" color="white" animation="tada-hover" size="45px" style="margin-top: 17px;" ></box-icon></center></span>
<br>
<span style="font-size:30px;color:black">{value}</span>
<br><br><br><br><br>
<span style="color: black;font-size:18px;">{text}</span>
</div>
</div>
<style>
.card
    {
        width:550px;
        height:300px;
        border-radius: 5px;
        background-color: white;
        padding: 25px;
        color:black;
        margin-bottom: 25px;
    }
.dot {
  height: 75px;
  width: 75px;
  background-color: #bbb;
  border-radius: 50%;
  display: inline-block;
  margin-left: 250px;

}
</style>
