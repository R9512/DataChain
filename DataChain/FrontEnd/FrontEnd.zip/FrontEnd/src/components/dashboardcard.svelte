<script>

    import 'boxicons'
    export let icon=""
    export let name=""
    export let text = ""
    export let value=""
</script>


<div class="flip-box">
    <div class="flip-box-inner">
      <div class="flip-box-front">
        <box-icon name={icon} type = "logo" color="white" animation="tada-hover" size="120px" style="float: right;" ></box-icon>
        <h1>{name}</h1>
        <br>
        <br>
        <br>
        <span style="font-size: 63px;font-weight:bold">{value}</span>
      </div>
      <div class="flip-box-back">
        <h3>
            <h2>{name}</h2>
            {text}
        </h3>
      </div>
    </div>
  </div>
   <style>
.flip-box 
{
  background-color: transparent;
  width: 450px;
  height: 300px;
  border: 1px solid #f1f1f1;
  perspective: 1000px;
}

.flip-box-inner {
  position: relative;
  width: 100%;
  height: 100%;
  text-align: center;
  transition: transform 0.8s;
  transform-style: preserve-3d;
}

.flip-box:hover .flip-box-inner {
  transform: rotateX(180deg);
}

.flip-box-front, .flip-box-back {
  position: absolute;
  width: 100%;
  height: 100%;
  -webkit-backface-visibility: hidden;
  backface-visibility: hidden;
}

.flip-box-front {

  color: white;
  background-color: #f4511e;
}

.flip-box-back {

  background-color: dodgerblue;
  color: white;
  transform: rotateX(180deg);
  text-justify:distribute;
}
</style>