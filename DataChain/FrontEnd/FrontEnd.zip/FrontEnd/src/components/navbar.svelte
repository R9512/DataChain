<script>

</script>

<div class="topnav">
  <a href="main">Dashboard</a>
  <a href="new0">New</a>
  <a href="predict">Predict</a>
  <a href="contribute">Contribute</a>
  <a href="signup">LogIn</a>
</div>

<style>
  .topnav {
  overflow: hidden;
  background-color: #333;
}

.topnav a {
  float: left;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}


</style>