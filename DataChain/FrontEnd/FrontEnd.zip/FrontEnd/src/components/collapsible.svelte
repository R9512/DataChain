<script>
    export let heading
    export let desc
    export let tempid
    export let values
    import { createEventDispatcher } from 'svelte';
    const dispatch = createEventDispatcher();
function sairam()
{
  let temp = document.getElementsByClassName("collapsible")[tempid]
  temp.classList.toggle("active")
  var content = temp.nextElementSibling;
  if (content.style.maxHeight)
      content.style.maxHeight = null;
    else 
      content.style.maxHeight = content.scrollHeight + "px";
    

}

function send(item)
{
  dispatch('message',{"clicked":item})
}
</script>
<button class="collapsible" on:click={sairam}>{heading}</button>
<div class="content">
  {desc}
  <ul>
    {#each values as item}

    
      <li>
        <!-- svelte-ignore a11y-invalid-attribute -->
        <a href='#' on:click={()=>{send(item)}}>{item}</a>
      </li>
    {/each}
  </ul>
</div>

<style>
    .collapsible {
      background-color: #777;
      color: white;
      cursor: pointer;
      padding: 18px;
      width: 100%;
      border: none;
      text-align: left;
      outline: none;
      font-size: 15px;
    }
    
    .collapsible:after {
      content: '\002B';
      color: white;
      font-weight: bold;
      float: right;
      margin-left: 5px;
    }
    
    
    .content {
      padding: 0 18px;
      max-height: 0;
      overflow: hidden;
      transition: max-height 0.2s ease-out;
      background-color: #f1f1f1;
    }
    </style>