
<script>
  import { onMount } from "svelte";
  export let title
  export let tags
  export let link
  export let vpath
  export let sd
  export let bounty
  export let reached
  export let target
  let s=""
  
  import Tags from "./tags.svelte"
  onMount(async function () 
  {
    s = tags.split(",")

    s.pop()
    
  });
</script>
<div class="card">
  <div class="container">

 <center><h2> {title.slice(0,-1)}</h2></center>
<h4>{sd}</h4>
<h4>Bounty(ETH,USD):{bounty},{bounty*75}</h4>
<h4>{reached},Data Points Collected Out Of {target}</h4>
<div class='tags' style="display:none" id="base"> sairam</div>

 <div id = "tagholder">
  {#if s === undefined}
  Loading Character Name...
{:else}
<div class="grid-container">
  {#each s as models}
  <div class="grid-item"><Tags tagname = {models}/></div>
  {/each}
</div>   
      
{/if}
 </div>
 <a href="{link}" id = "ah">
<br>
  <center><button class="btn info" id = "butn">{vpath}</button></center>
</a> 
  </div>
</div>

<style>
  .grid-container {
  display: grid;
  grid-template-columns: auto auto auto;
  
}
.grid-item {
  align-items: center;
  text-align: center;
}
      .btn {
      border: 2px solid black;
      background-color: white;
      color: black;
      padding: 14px 28px;
      font-size: 16px;
      cursor: pointer;
    }
    .info {
      border-color: #2196F3;
      color: dodgerblue;
    }

    .info:hover {
      background: #2196F3;
      color: white;
    }
    .card {
      box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2);
      transition: 0.3s;
      width: 80%;
      height: 100%;

      min-width: 600px;
      max-width: 800px;
    }
    
    .card:hover {
      box-shadow: 0 8px 16px 0 rgba(0,0,0,0.2);
    }
    
    .container {
      padding: 2px 16px;
    }
    .tags {
  background-color: #ddd;
  border: none;
  color: black;
  padding: 10px 20px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  margin: 4px 2px;
  cursor: pointer;
  border-radius: 16px;
}
</style>