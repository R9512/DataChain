<script>
    import {onMount} from "svelte"
    import {Button} from 'svelte-mui'
    import {goto} from '@roxi/routify'
    export let value;
    let temp
    let count =Number(value)
    onMount(async function ()
    {
        temp=document.getElementById("li"+value)
        
        temp.style.background='white'
        temp.style.color='#f4511e'
  
    });
    function pagechanger(val)
    {
        count += val
        if(count<0)
            {count=0;}
        if(count==4)
            count = 3
        $goto("../new"+count)
        //alert(count)

    }
</script>

<ul >

<Button raised = true color="primary" on:click={()=>{pagechanger(-1)}}>&LT&LT</Button>

    <li id="li0">1</li>
    <li id="li1">2</li>
    <li id="li2">3</li>
    <li id="li3">4</li>

  <Button raised = true color="primary" on:click={()=>{pagechanger(1)}}>>></Button> 
  </ul>  


<style>

li {
  width: 2em;
  height: 2em;
  text-align: center;
  line-height: 2em;
  border-radius: 1em;
  background: #f4511e;
  margin: 0 1em;
  display: inline-block;
  color: white;
  position: relative;
}

li::before{
  content: '';
  position: absolute;
  top: .9em;
  left: -4em;
  width: 4em;
  height: .2em;
  background: #f4511e;
  z-index: -1;
}


li:first-child::before {
  display: none;
}

</style>