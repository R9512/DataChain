
<script>
    import {onMount} from 'svelte'
    export let message;
    export let rectime;
    export let position;
    onMount(
        async()=>{
            if(position===0)
            {
                const temp = document.getElementsByClassName("chip")[-1]
                temp.style.backgroundColor="#add8e6"
                temp.style.marginLeft="90%"

            }
        }
    )

</script>
<div class="chip">
    {message}
    <br><span style="font-size:10px;">{rectime}</span>
</div>
<style>
.chip 
{
    padding: 0 25px;
    font-size: 18px;
    border-radius: 20px;
    background-color: #f1f1f1;
    line-height: 1.5;
    min-height:50px;
    max-width: fit-content;
    overflow-wrap: break-word;
    
}
    
</style>
    