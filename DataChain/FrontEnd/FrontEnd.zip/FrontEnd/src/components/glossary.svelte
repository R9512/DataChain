<script>
    import 'boxicons'
    export let name
    export let desc
    export let adva
    export let disd

</script>
<div class="cont">
<h2 style="margin-left: 40%;">{name}</h2>
<p>{desc}</p>
<table class="tab" border=0>
    <tr>
        <td>
            <table >
                <tr>
                    <td style="width:50%"><box-icon name="right-top-arrow-circle" type = "logo" color="green" animation="tada-hover" size="45px"  ></box-icon></td>
                    <td ><h2>Pros</h2></td>
                </tr>
            
            </table>
        </td>
        <td>
            <table>
                <tr>
                    <td style="width:50%"><box-icon name="left-down-arrow-circle" type = "logo" color="red" animation="tada-hover" size="45px"  ></box-icon></td>
                    <td><h2>Cons</h2></td>
                </tr>
            </table>
        </td>
        
    </tr>
    <tr>
        <td>
            <ul>
                {#each adva as pro}
                <li>{pro}</li>
                {/each}
            </ul>
        </td>

        <td>
            <ul>
                {#each disd as con}
                <li>{con}</li>
                {/each}
            </ul>
        </td>
    </tr>
</table>

</div>

<style>
    
.cont 
{
    background-color: #f5f5f5;
    width: 100%;
    border-radius: 10px;
    border: 1px solid black;
}
.tab
{   
    margin-left: 15%;
    background-color: #eeeeee;
}
td
{
    width:500px;
}
</style>