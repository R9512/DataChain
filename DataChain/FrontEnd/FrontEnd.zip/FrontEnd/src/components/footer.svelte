<script>

</script>
<div id = "footer">
    <br><br><br>
    <h1 style="text-align:center;font-size:50px;font-style:italic">DataChain</h1>
    <p style="text-align:center;font-size:20px">Powered By River, Sklearn, Tensorflow</p>
    
</div>
<style>
#footer
{
    padding-top: 500;
    background-color: #f4511e;
    color: white;
    bottom:0%;
    width:100%; 
    height: 300px;
 
}
</style>