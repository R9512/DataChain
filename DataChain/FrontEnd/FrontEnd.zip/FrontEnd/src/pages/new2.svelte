<script>
  import Step from "../components/step.svelte"
  import Navbar from "../components/navbar.svelte";
  import { Textfield } from 'svelte-mui';
  import 'boxicons'
  import params from "../json/Params.json";
  import {countdetails,model,learning} from './stores'
  import Collapse from "../components/collapse.svelte"
  
  let title
  let tags
  let sd
  let value = ``;
  let count 

  let  temp3 =""
  model.subscribe(value => {temp3 = value});
  let temp4=""
  learning.subscribe(value => {temp4 = value});
  let parameters = []
  for(let x =0;x<params.length;x++)
    {
      if(params[x].name===temp3 && params[x].in===temp4)
          {parameters = params[x]}
    }
  
  function attributeadder()
  {
    const ele = document.getElementById("base")
    
    let newel = ele.cloneNode(true)
    newel.style = ""
    document.getElementById("attributes").appendChild(newel)
  }

  function attributeremover()
  {
    const temp = document.getElementById("attributes")
    if(temp.children.length >= 1)
    temp.removeChild(temp.children[temp.children.length -1]);
  }

  function creator()
  {
    //alert("Sairam")
    const temp1 = document.getElementsByClassName("attributename")
    const temp2 = document.getElementsByClassName("attributetype")
    var x =1
    var schema ={}
    for(x=1;x<temp1.length;x++)
    {
      schema[temp1[x].value] = temp2[x].value
    }
    //alert(parameters.params.length+"asidhbaifhgaoip")
    var hyperparams = {}
  for(var i = 0;i<parameters.params.length;i++)
    {
      console.log("Sairma")
      if(parameters.value[i]=="none")
      {
        //alert(parameters.default[i]+"Valeu is changed") 
        parameters.value[i] = parameters.default[i]
      }

      //hyperparams[parameters.params[i]] =parameters.value[i]
    }
    console.log(hyperparams)
   var details = {}
    details["model"] = temp3
    details["learning"] = temp4
    details["schema"] = schema
    details["title"] = title
    details["tags"] = tags
    details["sd"] = sd
    details["fd"] = value
    details["hp"] = parameters.value
    alert("Setting the Details")
    countdetails.set(details)
    console.log(details)
  }

</script>

<Navbar />
<div class="cont" >

<Step value=2/>
<h2>Model Specification</h2>
<div>
  
  <Textfield  autocomplete="off" bind:value={title} message="Please Enter the Title of the Model" label="Model Title" filled=true  required    />

  <br>
  <Textfield  autocomplete="off" bind:value={sd} message="Please enter short discription of the model. First 200 characters will be considered." label="Short Discription" filled=true  required      />
  <br>
  <Textfield  autocomplete="off" bind:value={tags} message="Please Enter the Tags for the Model seperated by the commas(Max 9). Eg: classification,reviewclassifer" label="Tags " filled=true  required      />
  <br>
  <textarea bind:value placeholder="Full Discription Goes Here"></textarea>
</div>
<Collapse headerText={'Advanced Settings'} >
	<div class="content">
    <h5>These are the advanced options availabe for tuning purpose only. Better Accept The Defaults</h5>
    {#each parameters.params as name, index}

    <Textfield bind:value={parameters.value[index]} message = {parameters.desc[index]} show=true label={name} filled=true />
	{/each}
	</div>
</Collapse>




<div id="base" style="display: none;">
    <table>
      <tr>
        <td><input class="attributename" type="text" placeholder="Attribute Name"/></td>
        <td>
          <select class="attributetype" name="cars" id="cars">
          <option value="int">Integer</option>
          <option value="float">Float</option>
          <option value="bool">Boolean</option>
          <option value="str">String</option>
        </select>
      </td>
       </tr>
      
    </table> 
  </div>
  <div id = "attributes" style="margin-left: 35%;"></div>
  <h3>Attributes</h3>
<table border=0 style="margin-left: 30%;">
  <tr>
    <td><button class="button" on:click={attributeadder}><box-icon name="plus-circle"  color="#f4511e" animation="tada-hover" size="30px" style="float: right;" ></box-icon></button></td>
    <td><h2>Attributes</h2></td>
    <td><button class="button" on:click={attributeremover}><box-icon name="minus-circle"  color="#f4511e" animation="tada-hover" size="30px" style="float: right;" ></box-icon></button></td>
  </tr>
</table>
<button class="button1" on:click={creator}><span>OK </span></button>
</div>
<style>
.cont 
{
      background-color: #f5f5f5;
      margin-left: 30%;
      width: 40%;
      border-radius: 10px;
}
textarea { width: 100%; height: 200px;resize: none; }

.cont
{
  background-color: #f5f5f5;
  margin-left: 25%;
  width: 50%;
}
.button {
  background-color: #f5f5f5;
  border: none;
}
.button1 {
  border-radius: 4px;
  background-color: #f4511e;
  border: none;
  color: #FFFFFF;
  text-align: center;
  font-size: 24px;
  padding: 15px;
  width: 200px;
  transition: all 0.5s;
  cursor: pointer;
  margin: 5px;
  margin-left:70%
}

.button1 span {
  cursor: pointer;
  display: inline-block;
  position: relative;
  transition: 0.5s;
}

.button1 span:after {
  content: '\00bb';
  position: absolute;
  opacity: 0;
  top: 0;
  right: -20px;
  transition: 0.5s;
}

.button1:hover span {
  padding-right: 25px;
}

.button1:hover span:after {
  opacity: 1;
  right: 0;
}
</style>