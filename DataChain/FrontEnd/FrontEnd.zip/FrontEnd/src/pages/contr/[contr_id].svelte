<script>
    import { metatags } from "@roxi/routify";
    import { params } from "@roxi/routify"
    import { onMount } from "svelte";    
    import {userd} from '../stores'

    import Tags from "../../components/tags.svelte"
    import Navbar from "../../components/navbar.svelte";
    let user_id = $params.contr_id;
    
    let title = "Sairam"
    let desc = ""
    let schema = ""
    let s = ""
    let attributes = []
    let useraddress;
  let learning
    let schema1 = {}//JSON object To Send
    onMount(async function () 
  {
    alert(user_id+"Fasak")
    const endpoint = "http://localhost:3000/contribute?id="+user_id
    const response = await fetch(endpoint);
    const data1 = (await response.json());
    alert("Sai")
    console.log(data1)
    title = data1[0][2]
    desc = data1[0][3]
    s = data1[0][4].split(',')
    let temp = data1[1][0].split("'").join('"')
    learning = data1[0][1]
    console.log(temp)
    schema = JSON.parse(temp)
    userd.subscribe(value=>{useraddress = value})
   
    
  });

  const sairam = async () => {
        
    schema1 = {}
    let temp  = document.getElementsByTagName("input")
    schema1["modid"] = user_id
    schema1["learning"] = learning
    schema1["user"] = useraddress.account
    let schema2 = {}
    for(let x = 0;x<temp.length;x++)
    {
      schema2[temp[x].id] = temp[x].value
    }
    schema1["data"] = schema2
    console.log(schema1.data)
        
        let res = await fetch('http://localhost:3000/contribute', {
                method: 'POST',
          mode: 'cors', 
        cache: 'no-cache', 
        credentials: 'same-origin',
        headers: {'Content-Type': 'application/json'},
        redirect: 'follow',
        referrerPolicy: 'no-referrer',
        body: JSON.stringify(schema1) 
            })

          
          return(res.json())
          
      };
  function predictor()
  {
    sairam().then(data=>{
        alert("Predition is:"+data.output)
      })
  }

</script>
<Navbar/>
<div class="cont">
    <h1 style="margin-left: 30%;">Model Details</h1>
    <h3 style="margin-left: 30%;">Title:{title}</h3>
    <h3 style="margin-left: 30%;">Description:</h3>
    <div style="margin-left: 30%;width:60%">
        <p>{desc}</p>
    </div>
    <h3 style="margin-left: 30%;">Tags:</h3>
    <div style="margin-left:30%;width:50%">

    {#if s === undefined}
    Loading Character Name...
  {:else}
    {#each s as models}
    <Tags tagname = {models}/>
    {/each}
        
        
  {/if}

  <div style="margin-left: 0%;display:none" id ="base">
    <h4>Attribute Name - Type</h4>

  </div>
    </div>
    <div style="margin-left: 30%;">
      <h3>Data Entry</h3>
    
    
    {#each Object.entries(schema) as s}
 
      
        {s[0]} - {s[1]}:
        <input type="text" id={s[0]}/>
      
      
    
    {/each}

</div>
    
<button class="button1" on:click={predictor}><span>Contribute</span></button>
        <h3 style="margin-left: 30%;">Output:{user_id}</h3>
    </div>
    
<style>
.cont
{
  background-color: #f5f5f5;
  margin-left: 25%;
  width: 50%;
}
.button1 {
  border-radius: 4px;
  background-color: #f4511e;
  border: none;
  color: #FFFFFF;
  text-align: center;
  font-size: 18px;
  padding: 10px;
  width: 130px;
  transition: all 0.5s;
  cursor: pointer;
  margin: 5px;
  margin-left:70%
}

.button1 span {
  cursor: pointer;
  display: inline-block;
  position: relative;
  transition: 0.5s;
}

.button1 span:after {
  content: '\00bb';
  position: absolute;
  opacity: 0;
  top: 0;
  right: -20px;
  transition: 0.5s;
}

.button1:hover span {
  padding-right: 25px;
}

.button1:hover span:after {
  opacity: 1;
  right: 0;
}
</style>
