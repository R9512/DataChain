<script>
    import Footer from "../components/footer.svelte";
</script>
<Footer/>