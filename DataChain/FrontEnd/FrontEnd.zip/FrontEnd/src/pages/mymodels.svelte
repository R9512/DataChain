<script>
    import Navbar from "../components/navbar.svelte";
    import Footer from "../components/footer.svelte";
    import {onMount} from 'svelte'
    import { goto } from '@roxi/routify'
    import {userd} from "./stores"
    import Modelcard from "../components/modelcard.svelte"
    let udetails;
    let data = [];
    onMount(async function()
    {

  userd.subscribe(value => {udetails = value});
    alert("Swami")
    console.log(userd)
    alert("Sai")
    if(udetails==0)
        $goto('../usernotfound')
    const endpoint = "http://localhost:3000/mymodels"
    let details = { "account":udetails.account }
         const response = await fetch(endpoint,{
                method: 'POST',
          mode: 'cors', 
        cache: 'no-cache', 
        credentials: 'same-origin',
        headers: {'Content-Type': 'application/json'},
        redirect: 'follow',
        referrerPolicy: 'no-referrer',
        body: JSON.stringify({"account":udetails.account}) 
            })
    const data1 = (await response.json());
    data =data1.output[0]  
    })
    function openCity(cityName) 
    {
    var i, tabcontent, tablinks;
    tabcontent = document.getElementsByClassName("tabcontent");
    for (i = 0; i < tabcontent.length; i++) {
      tabcontent[i].style.display = "none";
    }
    document.getElementById(cityName).style.display = "block";
    
  }
</script>

     
<Navbar/>


<div class="tab">
  <!-- svelte-ignore missing-declaration -->
  <button class="tablinks" on:click={()=>{openCity('London')}}>Configure Models</button>
  <!-- svelte-ignore missing-declaration -->
  <button class="tablinks" on:click={()=>{openCity( 'Paris')}}>Tune Models</button>
</div>

<div id="London" class="tabcontent">
  <center><h2>Configure Models</h2></center>
  <p>The lsit of models that are yet to be configured. Note these models are not available for trainging and the user is expected to configure them by traing them by the availabe data.</p>
  <div class="grid-container">
    {#each data as model}
    <Modelcard title={JSON.parse(model).title} tags = {JSON.parse(model).tags} sd = {JSON.parse(model).sdesc} link = "./config/{JSON.parse(model).id}" vpath="Configure" />
    {/each}
  
</div>
</div>

<div id="Paris" class="tabcontent">
  <h3>Tune Models</h3>
 
</div>

<div id="Tokyo" class="tabcontent">
  <h3>Tokyo</h3>
  <p>Tokyo is the capital of Japan.</p>
</div>




<Footer/>
<style>
  .grid-container {
  display: grid;
  grid-template-columns: auto auto auto;
  padding: 10px;
}

  .tab {
    overflow: hidden;
    border: 1px solid #ccc;
    background-color: #f4511e;
    color:white
  }
  
  .tab button {
    background-color: inherit;
    float: left;
    border: none;
    outline: none;
    cursor: pointer;
    margin-left: 25%;
    transition: 0.3s;
    font-size: 25px;
    color:white;

    border-radius: 15px;
  }
  
  .tab button:hover 
  {
    background-color: white;color: #f4511e;

  }
  
  
  .tabcontent {
    display: none;
    padding: 6px 12px;
    border: 1px solid #ccc;
    border-top: none;
  }
  </style>
  