
<script>
  import 'boxicons'
  import Dashboardcard from '../components/dashboardcard.svelte';
  import { onMount } from "svelte";
  import { goto } from '@roxi/routify'
  import { beforeUpdate} from 'svelte';

  let values = {}

  beforeUpdate(async function()
  {
    if(sessionStorage.getItem("UserName")===null)
        $goto('../usernotfound')
  })
  onMount(async function () 
  {
    
  const endpoint = "http://127.0.0.1:3000/jsairam"
  const response = await fetch(endpoint);
  const data = await response.json();
  values = data
  values.br = Number((data.br).toFixed(3))
  values.bt = Number((data.bt).toFixed(3))
  values.hr/= 1000000000000

  values.hr = Number((values.hr).toFixed(3))

});


  function openNav() {
    
    document.getElementById("mySidenav").style.width = "250px";
    document.getElementById("main").style.marginLeft = "250px";

    
  }
  
  function closeNav() {

    document.getElementById("mySidenav").style.width = "0";
    document.getElementById("main").style.marginLeft= "0";
  }
  
  
  </script>
<div id="mySidenav" class="sidenav">
  <!-- svelte-ignore a11y-invalid-attribute -->
  <a href="javascript:void(0)" class="closebtn" on:click={closeNav}>&times;</a>
  <a href="new">New</a>
  <a href="c.com">Dummy1</a>
  <a href="c.com">Dummy2</a>
  <a href="c.com">Dummy3</a>
</div>

<div id="main" >
  <div class="navbar">
    <a href="#news" style="float: right;">Image</a>



      <span style="font-size:30px;cursor:pointer" on:click={openNav}>&#9776; </span>
  
  </div>

<table style="width:100%">
  <tr>
    <td><Dashboardcard name="Block Number" text="Blocks are data structures within the blockchain database, where transaction data in a cryptocurrency blockchain are permanently recorded. A block records some or all of the most recent transactions not yet validated by the network. Once the data are validated, the block is closed. Then, a new block is created for new transactions to be entered into and validated.Latest block number that is mined" icon = "calculator" value={values.bn}/></td>

    <td><Dashboardcard name="Block Reward" text="Bitcoin block rewards are new bitcoins awarded to cryptocurrency miners for being the first to solve a complex math problem and creating a new block of verified bitcoin transactions. The miners use networks of computers to do this, and every time a new block is created it is verified by all the other competing miners. Then a new math problem is introduced and the miners start over. " icon = "gift" value={values.br}/></td>

    <td><Dashboardcard name="Block Time" text="

      Block time is the length of time it takes to create a new block in a cryptocurrency blockchain. A block is verified by miners, who compete against each other to verify the transactions and solve the hash, which creates another block.Under the proof-of-work consensus mechanism, cryptocurrency is rewarded for solving a block's hash and creating a new block.Time taken to create a new block expressed in seconds" icon = "timer" value={values.bt}/></td>

    <td><Dashboardcard name="Price" text="Real Time Ether value in US Dollars" icon = "dollar" value={values.price}/></td>
  </tr>
  <tr style="padding-left:20%">
    <td></td>
    <td><Dashboardcard name="HashRate" text="Hashrate reflects the performance of mining hardware. It is measured in solutions per second. A solution in the Ethereum network is called a hash, or simply h. Mining performance is measured in h/s (hashes per second).Here it is expressed in Terra Hashes" icon = "hash" value={values.hr}/></td>

    <td><Dashboardcard name="Ethers Mined" text="Ether is the transactional token that facilitates operations on the Ethereum network. All of the programs and services linked with the Ethereum network require computing power (and that computing power is not free). Ether is a form of payment for network participants to execute their requested operations on the network. Total number of Ether mined." icon = "coin-stack" value={values.tc}/></td>

    
  </tr>
</table>

<h3 style="align:center">Terms And Conditions Goes Here... Still Work In Progress</h3>
</div>
<style>


.navbar {
  width: 100%;
  background-color: #f4511e;
  overflow: auto;
}

.navbar a {
  float: left;
  padding: 12px;
  color: white;
  text-decoration: none;
  font-size: 17px;
}

.navbar a:hover {
  background-color: white;
}


@media screen and (max-width: 500px) {
  .navbar a {
    float: none;
    display: block;
  }
}
.sidenav {
  height: 100%;
  width: 0;
  position: fixed;
  z-index: 1;
  top: 0;
  left: 0;
  background-color: #f4511e;
  color:white;
  overflow-x: hidden;
  transition: 0.5s;
  padding-top: 60px;
}

.sidenav a {
  padding: 8px 8px 8px 32px;
  text-decoration: none;
  font-size: 25px;
  color: white;
  display: block;
  transition: 0.3s;
}

.sidenav a:hover {
  color: #f4511e;
  background-color: white;
}

.sidenav .closebtn {
  position: absolute;
  top: 0;
  right: 25px;
  font-size: 36px;
  margin-left: 50px;
}

#main {
  transition: margin-left .5s;
  padding: 16px;
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}
</style>
  