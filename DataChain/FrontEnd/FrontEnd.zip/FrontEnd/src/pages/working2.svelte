<script>
    import {ethers} from "ethers"
const swami = async()=>{
  let temp = await window.ethereum.request({ method: 'eth_requestAccounts' });
  alert(typeof(temp.toString()))
  const sender = temp.toString()
  const provider = new ethers.providers.Web3Provider(window.ethereum)
  
  const signer = provider.getSigner()
  
  const reciever = "0x806974FEF10a380723A42fbc5dc46189765f9bc4"
  alert(sender+"::")

  const tx = {
      from:sender,
      to:reciever,
      value:ethers.utils.parseEther("1.0"),
    
  }
  try
  {
    const transaction = await signer.sendTransaction(tx)
  }
  catch(e)
  {
    alert("Error")
    console.log(e)
    return
    
  }
  return(true)
};
</script>
<button on:click={swami}>Click Me to Send Transctions</button>