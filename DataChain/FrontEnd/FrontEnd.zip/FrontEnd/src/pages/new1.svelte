<script>
    import Navbar from "../components/navbar.svelte";
    import { scale }  from "svelte/transition";
    import { Radio } from 'svelte-mui';
    import Step from "../components/step.svelte"
    import Collapsible from "../components/collapsible.svelte"  
    import info from "../json/Models.json";
    import Glossary from "../components/glossary.svelte";
    import {model,learning} from './stores'
     import { ExpansionPanel} from 'svelte-mui';
    
    

    const onchage = ({ detail }) => {
         detail.expanded ? 'open' : 'close', detail.name;
    };

let group = 'Incremental Learning';
let group1
let colors = {
    "Incremental Learning": 'green',
    "Machine Learning": 'blue',
    "Neural Network": '#f8e42d'
};
let temp1;

function handleMessage(event) 
{
		const temp = event.detail.clicked;
    model.set(temp)
    learning.set(group)
    sessionStorage.setItem("sai",temp)
    document.getElementById('myModal').style.display = "block";
    temp1 =document.getElementById(temp)
    document.getElementById("displayer").append(temp1)
    
    
}
function closeman()
 {
  document.getElementById('myModal').style.display = "none";
  document.getElementById("main").append(temp1)
}

window.onclick = function(event) {
  if (event.target == document.getElementById('myModal')) {
    document.getElementById('myModal').style.display = "none";
  }
}
function addColumn() 
{
			var table = document.getElementById("myTable");
			var row = table.getElementsByTagName("tr");
			var columnCount = 1

      var shower = document.getElementById("shower")
      shower.style=""
      var add = document.getElementById("base2").cloneNode(true)
      add.style=""
      shower.appendChild(add)
			for(var k = 0; k < columnCount; k++)
       {
				for (var i = 0; i < row.length; i++) 
        {
					var td = document.createElement('td');		
          var temp = document.getElementById("base1").cloneNode(true)
					td.innerHTML = temp.innerHTML;
					row[i].appendChild(td);
				}
			}
		}
		
		function deleteColumn() {
      var table = document.getElementById("myTable");
			var row = table.getElementsByTagName("tr");
			var columnCount = 1
      var temp = document.getElementById("shower")
      temp.removeChild(temp.children[temp.children.length -1]);
     
			for(var k = 0; k < columnCount; k++) {
				for (var i = 0; i < row.length; i++) {
					row[i].deleteCell(0);
				}
			}
		}
		
  </script>
  
  <Navbar />
  <div class="cont" >

<div style="margin-left: 20%;"><Step value=1/></div>
      <table>
          <tr>
            {#each Object.keys(colors) as key}

            <td>
    <Radio bind:group color={colors[key]} value={key}>
        <span>{key}</span>
    </Radio>
</td>
{/each}
          </tr>
      </table>

{#if group=="Incremental Learning"}
<div class="q"  in:scale >
  <h4>Incremental learning is a machine learning paradigm where the learning process takes place whenever new examplses emerge and adjusts what has been learned according to the new example.</h4>

<Collapsible on:message={handleMessage} tempid=0 heading="Linear Models"   desc={"This is the Description"} values={["Linear Regression","Logistic Regression","Softmax Regression","ALMA Classifier"]}/>
<Collapsible on:message={handleMessage}  tempid=1 heading="Ensemble Learning"  desc={"This is the Description"} values={["Adaboost Classifier","AdaptiveRandom Forest Classifier","AdaptiveRandom Forest Regressor","Bagging Regressor"]}/>
<Collapsible on:message={handleMessage}  tempid=2 heading="Trees"  desc={"This is the Description"} values={["Extremely Fast Decision Tree","Hoeffding Adaptive Tree Classifier","Hoeffding Adaptive Tree Regressor","SGT Regressor "]}/>
<Collapsible on:message={handleMessage}  tempid=3 heading="Clustering"  desc={"This is the Description"} values={["DBSTREAM","DenStream","KMeans","STREAMKMeans"]}/>
</div>
{/if}
{#if group=="Machine Learning"}
<div class="q" in:scale >
  <Collapsible on:message={handleMessage} tempid=0 heading="Linear Models"  desc={"This is the Description"} values={["Linear Regression","Logistic Regression","Softmax Regression","ALMA Classifier"]}/>
  <Collapsible on:message={handleMessage}  tempid=1 heading="Ensemble Learning"  desc={"This is the Description"} values={["Adaboost Classifier","AdaptiveRandom Forest Classifier","AdaptiveRandom Forest Regressor","Bagging Regressor"]}/>
  <Collapsible on:message={handleMessage}  tempid=2 heading="Trees"  desc={"This is the Description"} values={["Extremely Fast Decision Tree","Hoeffding Adaptive Tree Classifier","Hoeffding Adaptive Tree Regressor","SGT Regressor "]}/>
  <Collapsible on:message={handleMessage}  tempid=3 heading="Clustering"  desc={"This is the Description"} values={["DBSTREAM","DenStream","KMeans","STREAMKMeans"]}/>
  
</div>

{/if}
{#if group=="Neural Network"}
<div class="q" in:scale >
  <div class="container">
    <ExpansionPanel name="Caution" bind:group1 on:change={onchage}>
      <div>
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Reiciendis quod culpa et,
          dolores omnis, ipsum in perspiciatis porro ut nihil molestiae molestias tenetur delectus
          velit! Inventore laborum rerum at id?
      </div>
  </ExpansionPanel>
  <table id="myTable" cellpadding="10" cellspacing="1" >
		
    <tr>
      <td>
        <div style="border: 1px solid black;">
          <span class="dot"></span><br>
          <span class="dot"></span><br>
          <span><center>.</center></span><br>
          <span><center>.</center></span><br>
          <span><center>.</center></span><br>
          <span class="dot"></span><br>
          <span class="dot"></span><br>
        </div>
      </td>
    </tr>
  
  </table>
  <div style="background-color: #dddddd;">
  <button on:click={addColumn}>+</button>
  <button on:click={deleteColumn}>-</button>

  <div id = "base1" style="border: 1px solid black;display:none">
    <span class="dot"></span><br>
    <span class="dot"></span><br>
    <span><center>.</center></span><br>
    <span><center>.</center></span><br>
    <span><center>.</center></span><br>
    <span class="dot"></span><br>
    <span class="dot"></span><br>
  </div>

    <div id = "base2" style="display: none;">
      <input type="text" placeholder="Layer Size:128"/>
        
    <select name="activation" id="af">
    <option value="relu">ReLU</option>
    <option value="tanh">TANH</option>
    <option value="sigmoid">SIGMOID</option>
    <option value="relu6">ReLU6</option>
    </select>
    </div>
<div id="shower">

</div>
</div>
</div>

<script>
   
</script>



</div>
{/if}

  <div id = "main" style="display: none;">
    {#each info as model}
    <div id={model.name}>
    <Glossary name = {model.name} desc = {model.desc} adva={model.adva} disd={model.disd}/>
    </div>
    {/each}
    
    </div>
</div>



<div id="myModal" class="modal">

  <div class="modal-content">
    <span class="close" on:click={closeman}>&times;</span>
    
  <div id ="displayer" in:scale></div>  
</div>

</div>
  <style>
    .dot {
  height: 25px;
  width: 25px;
  background-color: #bbb;
  border-radius: 50%;
  display: inline-block;
}
  .modal {
  display: none; 
  position: fixed; 
  z-index: 1;
  padding-top: 100px; 
  left: 0;
  top: 0;
  width: 100%;
  height: 100%; 
  overflow: auto; 
  background-color: rgb(0,0,0); 
  background-color: rgba(0,0,0,0.4); 
  transition-duration: 0.2s;
  }

  .modal-content {
  background-color: #fefefe;
  margin: auto;
  padding: 20px;
  border: 1px solid #888;
  width: 80%;
  }
  .close {
  color: #aaaaaa;
  float: right;
  font-size: 28px;
  font-weight: bold;
  }

  .close:hover,
  .close:focus {
  color: #000;
  text-decoration: none;
  cursor: pointer;
  }
    .cont 
    {
      background-color: #f5f5f5;
      margin-left: 30%;
      width: 40%;
      border-radius: 10px;
    }
    table 
    {
          border-collapse: separate;
          border-spacing: 0 15px;
          align-items: center;
          margin-left: 05%;
    }
        td 
    {
          text-align: left;
          border-bottom: 1px solid black;
          padding: 5px;
     }
      
      .q
      {
        background-color: #DDD;
        min-height: 300px;
        max-height: 300px;
  
      }
 
  </style>
  