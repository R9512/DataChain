<script>
    import { ethers } from "ethers";
    import { Snackbar, Button } from 'svelte-mui';
    import { goto } from '@roxi/routify'
    import {userd} from './stores'
    let visible = false;
    let message = 'Account Is Created';
    let name = '';
    let password = '';
    let sign = ''
    let account = ""
    const sairam = async () => {
        
      try 
      {

        if(name=="" || password=="")
        {
          message = "Please Fill The Credentials"
          visible=true
          return
        }
        if (!window.ethereum)
          throw new Error("No crypto wallet found. Please install it.");
        account = await window.ethereum.request({ method: 'eth_requestAccounts' });
        const provider = new ethers.providers.Web3Provider(window.ethereum);
        const signer = provider.getSigner();
        const signature = await signer.signMessage(password);
        sign = signature

       
      } 
      catch (err) 
      {
        message = err.message
        visible = true
        return
      }
      
      let res = await fetch('http://localhost:3000/login', {
                method: 'POST',
          mode: 'cors', 
        cache: 'no-cache', 
        credentials: 'same-origin',
        headers: {'Content-Type': 'application/json'},
        redirect: 'follow',
        referrerPolicy: 'no-referrer',
        body: JSON.stringify({
              
              "name":name,
              "sign":sign
    
            }) 
            })
        return(res.json())
        
    };
    function fun()
    {
      sairam().then(data=>{
        message = data.output
        if(message=="rightuser")//May Be SHould Change it
         {
             
          userd.set({
            "name":name,"account":account.toString()
          })
         $goto("../main")
         }
         else
         {message = "Check Your Credentials";visible = true}

      })
    }
    </script>
    <div class="main">
      <Snackbar bind:visible bg="#f4511e">
        {message}
        <span slot="action">
            <Button color="#ff0" on:click={() => (visible = false)}>Close</Button>
        </span>
    </Snackbar> 
    <div class="box-form">
        <div class="left">
            <div class="overlay">
            <h1>Data Chain</h1>
            <p>Powered By Blockchain along with Incremental Learning</p>
            <span>
                <p>MetaMask Wallet Is Necessary For The Working of The Datachain </p>
                
                <a href="https://metamask.io/download"><i class="" aria-hidden="true"></i> Get MetaMask</a>
            </span>
            </div>
        </div>
        
        
            <div class="right">
            <h5 style="color: #97ABFF;">LogIn</h5>
            <p>Don't have an account? <a href="/signup">Creat Your Account</a> it takes less than a minute</p>
            <div class="inputs">
                <input bind:value={name} placeholder="Username">
                <br>
                <input bind:value={password}  type="password" placeholder="Password">
            </div>
                
                <br><br>
            
                <br>
                <button on:click="{fun}">Login</button>
                
        </div>
        
    </div>
    </div>
    <style>
    .main{
      background-image: linear-gradient(135deg, #FAB2FF 10%, #1904E5 100%);
      background-image: linear-gradient( 135deg, #92FFC0 10%, #002661 100%);
      background-size: cover;
      background-repeat: no-repeat;
      background-attachment: fixed;
      font-family: "Open Sans", sans-serif;
      color: #333333;
      width: 100%;
      height: 950px;
      border: none;
    }
    
    .box-form {
      margin: 0 auto;
      width: 80%;
      background: #FFFFFF;
      border-radius: 10px;
      overflow: hidden;
      display: flex;
      flex: 1 1 100%;
      align-items: stretch;
      justify-content: space-between;
      box-shadow: 0 0 20px 6px #090b6f85;
    }
    @media (max-width: 980px) {
      .box-form {
        flex-flow: wrap;
        text-align: center;
        align-content: center;
        align-items: center;
      }
    }
    .box-form div {
      height: auto;
    }
    .box-form .left {
      color: #FFFFFF;
      background-size: cover;
      background-repeat: no-repeat;
      background-image: url("https://i.pinimg.com/736x/5d/73/ea/5d73eaabb25e3805de1f8cdea7df4a42--tumblr-backgrounds-iphone-phone-wallpapers-iphone-wallaper-tumblr.jpg");
      overflow: hidden;
    }
    .box-form .left .overlay {
      padding: 30px;
      width: 100%;
      height: 100%;
      background: #52E5E7;
      background-image: linear-gradient( 135deg, #52E5E7 10%, #130CB7 100%);
      overflow: hidden;
      box-sizing: border-box;
    }
    .box-form .left .overlay h1 {
      font-size: 10vmax;
      line-height: 1;
      font-weight: 900;
      margin-top: 40px;
      margin-bottom: 20px;
    }
    .box-form .left .overlay span p {
      margin-top: 30px;
      font-weight: 900;
    }
    .box-form .left .overlay span a {
      background: #3b5998;
      color: #FFFFFF;
      margin-top: 10px;
      padding: 14px 50px;
      border-radius: 100px;
      display: inline-block;
      box-shadow: 0 3px 6px 1px #042d4657;
    }
    .box-form .left .overlay span a:last-child {
      background: #1dcaff;
      margin-left: 30px;
    }
    .box-form .right {
      padding: 40px;
      overflow: hidden;
    }
    @media (max-width: 980px) {
      .box-form .right {
        width: 100%;
      }
    }
    .box-form .right h5 {
      font-size: 6vmax;
      line-height: 0;
    }
    .box-form .right p {
      font-size: 14px;
      color: #B0B3B9;
    }
    .box-form .right .inputs {
      overflow: hidden;
    }
    .box-form .right input {
      width: 100%;
      padding: 10px;
      margin-top: 25px;
      font-size: 16px;
      border: none;
      outline: none;
      border-bottom: 2px solid #B0B3B9;
    }
    
    .box-form .right .remember-me--forget-password input {
      margin: 0;
      margin-right: 7px;
      width: auto;
    }
    .box-form .right button {
      
      color: #fff;
      font-size: 16px;
      padding: 12px 35px;
      border-radius: 50px;
      display: inline-block;
      border: 0;
      outline: 0;
      box-shadow: 0px 4px 20px 0px #5961F9;
      background-image: linear-gradient( 135deg, #EE9AE5 10%, #5961F9 100%);
    }
    
    
    
    
    </style>