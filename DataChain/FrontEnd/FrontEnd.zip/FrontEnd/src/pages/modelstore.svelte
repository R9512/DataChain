<script>
    import Modelcard1 from "../components/modelcard1.svelte" 
    import Navbar from "../components/navbar.svelte";
    import { onMount } from "svelte";
    import {goto} from "@roxi/routify"
    import {beforeUpdate} from "svelte"
    let data
    let temp=[]
    
    onMount(async function () 
  {
     const endpoint = "http://localhost:3000/modelstore"
    const response = await fetch(endpoint);
    const data1 = (await response.json());
    console.log(data1)
    data = data1
    
  });
</script>
<main>
<Navbar/>
<div class="grid-container">
    {#if data === undefined}
        Loading Character Name...
    {:else}
        {#each data as models}
        <Modelcard1 title = {models[1]}, tags={models[2]}, link={"contr/"+models[0]} sd = {models[6]} vpath={"Contribute"} bounty={models[5]} reached={models[3]} target={models[4]}/>
        
        {/each}
            
            
    {/if}
</div>
</main>
<style>
.grid-container {
  display: grid;
  grid-template-columns: auto auto auto;
  
}
</style>