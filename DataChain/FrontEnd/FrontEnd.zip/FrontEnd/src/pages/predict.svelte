<script>
    import Modelcard from "../components/modelcard.svelte" 
    import Navbar from "../components/navbar.svelte";
    import { onMount } from "svelte";
    import { beforeUpdate } from "svelte";
    import { goto } from '@roxi/routify'

    let data
    let temp=[]
    beforeUpdate(async function()
  {
    if(sessionStorage.getItem("UserName")===null)
        $goto('../usernotfound')
  })
    onMount(async function () 
  {
    const endpoint = "http://localhost:3000/predict"
    const response = await fetch(endpoint);
    const data1 = (await response.json()).output;
    for(var a =0;a<data1.length;a++)
        {temp.push(JSON.parse(data1[a]));
        }
    data = temp
  });
</script>
<main>
<Navbar/>
    {#if data === undefined}
        Loading Character Name...
    {:else}
        {#each data as models}
        <Modelcard title = {models.title}, tags={models.tags}, link={models.modelid} vpath={"model"}/>
        
        {/each}
            
            
    {/if}
</main>