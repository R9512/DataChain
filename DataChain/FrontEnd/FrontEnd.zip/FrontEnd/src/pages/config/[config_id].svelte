<script>
    import { metatags } from "@roxi/routify";
    import { params } from "@roxi/routify"
    import { onMount } from "svelte";    
    import Tags from "../../components/tags.svelte"
    import Navbar from "../../components/navbar.svelte";
    let modle_id = $params.config_id;
    
    let title = "Sairam"
    let desc = ""
    let learning = ""
    let s = ""
    let schema = ""
    onMount(async function () 
  {
    const endpoint = "http://localhost:3000/configure?id="+modle_id
    const response = await fetch(endpoint);
    const data1 = (await response.json());
    
    const data = data1.output
    console.log(data)
    
    title = data['title']
    desc = data['ldesc']
    s = data['tags'].split(',')
    schema = data['sdesc']
    learning = data["learning"]+"-"+data["method"]

  });
 async function swami()
  {
    const input = document.querySelector('input[type="file"]');
    const file = input.files[0];
    let formdata = new FormData()
    console.log(file)
    //let temp = 
    formdata.append('title',modle_id)
    formdata.append("lear",learning.split("-")[0])
    formdata.append("model",file)
    const options = {
          method: 'POST',
          mode: 'cors', 
          body: formdata,
          headers: { 'Content-Type': 'multipart/form-data', }
          };

          delete options.headers['Content-Type'];
    
    let res = await fetch('http://localhost:3000/configure', options)

  }

 
</script>
<Navbar/>
<div class="cont">
    <h1 style="margin-left: 30%;">Model Details</h1>
    <h3 style="margin-left: 30%;">Title:{title}</h3>
    <h3 style="margin-left: 30%;">Learning:{learning}</h3>
    <h3 style="margin-left: 30%;">Title:{title}</h3>
    
    <h3 style="margin-left: 30%;">Description:</h3>
    <div style="margin-left: 30%;width:60%">
        {desc}
    </div>
    <h3 style="margin-left: 30%;">Tags:</h3>
    <div style="margin-left:30%;width:50%">

    {#if s === undefined}
    Loading Character Name...
  {:else}
    {#each s as models}
    <Tags tagname = {models}/>
    {/each}
        
        
  {/if}

<h2>Ensure that the last column of the CSV file is the Predictor Variable </h2>


  <input type="file" style="margin-left: 5%;" id="model"/>

  <button class="button1" on:click={swami}><span>Configure Model</span></button>
</div>
</div>
    
<style>
.cont
{
  background-color: #f5f5f5;
  margin-left: 25%;
  width: 50%;
}
.button1 {
  border-radius: 4px;
  background-color: #f4511e;
  border: none;
  color: #FFFFFF;
  text-align: center;
  font-size: 18px;
  padding: 10px;
  width: 190px;
  transition: all 0.5s;
  cursor: pointer;
  margin: 5px;
  margin-left:70%
}

.button1 span {
  cursor: pointer;
  display: inline-block;
  position: relative;
  transition: 0.5s;
}

.button1 span:after {
  content: '\00bb';
  position: absolute;
  opacity: 0;
  top: 0;
  right: -20px;
  transition: 0.5s;
}

.button1:hover span {
  padding-right: 25px;
}

.button1:hover span:after {
  opacity: 1;
  right: 0;
}
</style>
