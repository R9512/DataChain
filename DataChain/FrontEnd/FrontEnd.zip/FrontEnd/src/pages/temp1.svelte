<script>
  import abi1 from "../contract/Simple.json";
  import {ethers} from "ethers"
  const addr = "0x8b6fDD5a01C6086aD7403d5da5bD6ddE97e3C106"
  const provider = new ethers.providers.Web3Provider(window.ethereum)
  const signer = provider.getSigner()
  const contract = new ethers.Contract(addr,abi1,signer)
  async function sairam()
{

  alert("From Sairam")
  const calling = await contract.newUser(7,"5","Swami","sai","sai")
  checkEvents()
return(" ")

}
function fun()
    {
      sairam().then(async (data)=>{
        alert(data)
      })
    }
async function checkEvents()
{
  let filter = {
    address: addr,
    topics: [ethers.utils.id("Created(string)")]
            }

contract.on(filter, (log, event) => {
  alert("Something")
  console.log(event)
  console.log(log)
})
}
</script>
<button on:click={fun}>Sairam</button>
