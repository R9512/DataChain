<script>
    //For the chat implementation of the DataChain
import Chartcard from "../components/chartcard.svelte";
import { Textfield } from 'svelte-mui';
import {onMount} from 'svelte';
let usermessage
let messages = []
let ws;
onMount(
   async function init() 
    {

      ws = new WebSocket("ws://localhost:9001/");      
      ws.onmessage = function(e)
       {
        let temp = {}
        temp.message = e.data
        temp.position = 1
        const current = new Date();
        const time = current.toLocaleTimeString("en-US", {hour: "2-digit",minute: "2-digit"});
        temp.rectime=time
        messages = [...messages, temp];
      };
      

      ws.onerror = function(e) {
        console.log(e)
      };

    }
)
function messagesender(event)
{
    if(event.keyCode==13)
    {
        let temp = {}
        const current = new Date();
        const time = current.toLocaleTimeString("en-US", {hour: "2-digit",minute: "2-digit"});
        temp.rectime = time
        temp.position = 0
        temp.message = usermessage

    ws.send(usermessage)
        usermessage = ""
        messages = [...messages, temp];
    var chatHistory = document.getElementById("messageBody");
    chatHistory.scrollTop = chatHistory.scrollHeight+50;
    }
}
</script>

<svelte:window on:keydown={messagesender}/>
<div style="background-color: #f4511e;color:white;width:100%;height:50px;font-size:50px">Rodda</div>
<div id = "messageBody"style="background-image: linear-gradient(to right, #00b4db, #0083b0);width:100%;height:800px;overflow-y: scroll;">

    {#each messages as chat}
    {#if chat.position == 0}
    <div style="color:red;display:block;margin-left:80%">
        <Chartcard message={chat.message} rectime={chat.rectime} position={chat.position}/><br>
    </div>
    {:else}
    <div style="color:blue;">
        <Chartcard message={chat.message} rectime={chat.rectime} position={chat.position}/><br>
    </div>
    {/if}
    {/each}
<br><br><br>
    
</div>

<Textfield bind:value={usermessage}  />
