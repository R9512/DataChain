
<Button on:click={something}>Some Button</Button>
<Dialog width="800" bind:visible>
    <h1>Something</h1>
    <div style="width: 100%;height:20px;background-color:black"></div>
    {message}
</Dialog>
<script>
    export let visible = false;
    let message = "Swamo"
    import { Dialog,Button } from 'svelte-mui';
    function something()
    {
        visible=true
        message="Swami Sairam...."
    }
</script>

<style>
</style>

