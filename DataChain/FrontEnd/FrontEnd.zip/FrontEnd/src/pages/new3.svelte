<script>
    import Step from "../components/step.svelte"
    import Navbar from "../components/navbar.svelte";
    import { Textfield } from 'svelte-mui';
    import {countdetails,ethval,userd} from './stores'
    import { Checkbox } from 'svelte-mui';
    import {ethers} from "ethers"
    import abi1 from "../contract/Simple.json"
    import {onMount} from "svelte"
    import { Snackbar, Button } from 'svelte-mui';

    let visible = false;
    let message = 'Snackbar message!';

    let details;let ethusd ;
    let useraddress =""
      let sender = 
    onMount(async function ()
    {
      let temp = await window.ethereum.request({ method: 'eth_requestAccounts' });
      sender = temp.toString()
      userd.subscribe(value=>{useraddress = userd})
     
    }
    )
    countdetails.subscribe(value => {details = value});
    ethval.subscribe(value => {ethusd = value});
      let makeds=false
      let makemod = false

    let total = '1';let dp = '10';let fordp = total/dp
    function calculator()
    {
          if(total==1 &&dp==10)
            return
          fordp = total/dp
    }
    const sairam = async () => {

    let res = await fetch('http://localhost:3000/newmodel', 
    {
                method: 'POST',
          mode: 'cors', 
        cache: 'no-cache', 
        credentials: 'same-origin',
        headers: {'Content-Type': 'application/json'},
        redirect: 'follow',
        referrerPolicy: 'no-referrer',
        body: JSON.stringify(details) 
            
      })
        return(res.json())  //Need to add the boolean varaibles for the selling private dataset etc
      };
  function creator(value)
  {   
      //details["hp"]=["56"]

      message = "Sending The Reqest to The Server!!"
        details['predict']=document.getElementById("topredict").value
        details['bounty'] = total
        details['target'] = dp 
        details["dssell"]=""+makeds
        details["modsell"] =""+makemod
 
        details["owner"] = sender
        console.log(JSON.stringify(details))
    sairam().then(data=>{

      message = "Response recieved. Model Created"
      return(contractcaller(data))})
  }
  async function fundssender(value)
  {
      console.log(value)
      let temp = await window.ethereum.request({ method: 'eth_requestAccounts' });
      const sender = temp.toString()
      const provider = new ethers.providers.Web3Provider(window.ethereum)  
      const signer = provider.getSigner()  
      const reciever = "0x9d7cA7510fb0b0DA937E5C0FC40905E60c87D510"//Change this based on the stuff
      const tx = {
            from:sender,
            to:reciever,
            value:ethers.utils.parseEther(total)}
      try
      {
      const transaction = await signer.sendTransaction(tx)
      }
      catch(e)
      {
            alert("Error")
            return(false)
            
      }
      //Return a JSON object from flask
      return(true)
  };
  async function contractcaller(value)
{

      message = "Entering the Details to the Blockchian"
  const addr = "0x7059Ba133c028fa02EC66F9C4406BAc4e94a9324"//SmartContract Address
  const provider = new ethers.providers.Web3Provider(window.ethereum)
  const signer = provider.getSigner()
  const contract = new ethers.Contract(addr,abi1,signer)
  //alert(value.modid+"::"+value.userid)
  await contract.newUser(parseInt(value.modid),value.userid,value.title,"sai","sai")
  checkEvents(addr,contract)

  message = "Waiting for the event from blockchian."


}
async function checkEvents(addr,contract)
{

  let filter = {address: addr,topics: [ethers.utils.id("Created(string)")]}
   contract.on(filter, (log, event) => {message="Model Created Sucessfully.";visible = false;
})
}
function caller()
{
      visible=true
      message = "Preparing the GateWay!!"
      fundssender().then(
            (value)=>{
                  if(value)
                  {
                        
                         message = "Funding Recieved!!"
                        let res = creator(value);


                  }
            }
      )

}

  </script>
  <svelte:window on:keydown={calculator}/>

  <Navbar />

  <Snackbar bind:visible bg="#f44336" timeout=0>
      {message}
      <span slot="action">
          <Button color="#ff0" on:click={() => (visible = false)}>Close</Button>
      </span>
  </Snackbar>
  <div class="cont" >
  
  <Step value=3/>
  
  <h2>Final Crypto and Ether Goes Here</h2>
  <table border = 0 style="margin-left: 20%;">

        <tr>
            <td>Model Type:</td><td>{details.model}</td>
      </tr>

      <tr>
            <td>Learning Type:</td><td>{details.learning}</td>
      </tr>
        <tr>
              <td>Model Title:</td><td>{details.title}</td>
        </tr>

        <tr>
            <td>Model Short Descritpion:</td><td>{details.sd}</td>
      </tr>

      <tr>
            <td>Model Full Descritpion:</td><td>{details.fd}</td>
      </tr>
      <tr>
            <td>Model Tags:</td><td>{details.tags}</td>
      </tr>
      <tr>
            <td>Model Schema:</td>
            <td>
                  {#each Object.keys(details.schema) as attribute }
                        {attribute}=>{details.schema[attribute]}<br>
                  {/each}
            </td>
      </tr>
  </table>
  <Textfield on:keypress={calculator}   label="Ethers"     required    outlined=true bind:value={total}    message="Total Number of Ether "/><br>
  <Textfield    label="Number of DataPoints"     required    outlined=true bind:value={dp}    message="Minimum Number of Data Points "/><br>
<table>
      <tr>
            <td>
                  <div id="rcorners1">
                        <h3>Unit Datapoint in Ether</h3>
                        <center style="font-size:25px">{Number(fordp).toFixed(8)}</center>
                  </div>
            </td>
            <td>
                  <div id="rcorners1">
                        <h3>Unit Datapoint in USD</h3>

                        <center style="font-size:25px">{Number(fordp*ethusd).toFixed(8)}</center>
                  </div>
            </td>
      </tr>
</table>
<br>
<br>
<div></div>
<h3>Predictor Variable</h3>
<select id="topredict">
      {#each Object.keys(details.schema) as name}
      <option>{name}</option>
      {/each}
</select>
<Checkbox bind:makeds ><span>Place the dataset in the market place </span> </Checkbox><br>

<Checkbox bind:makemod ><span>Place the model in the market place </span> </Checkbox>

  

<button class="button1" on:click={caller}><span>Create Model </span></button>
  </div>
  <style>
#rcorners1 {
  border-radius: 25px;
  background: #f4511e;
  color:white;
  padding: 20px; 
  width: 200px;
  height: 150px;  
}
  .cont 
  {
        background-color: #f5f5f5;
        margin-left: 30%;
        width: 40%;
        border-radius: 10px;
  }
  .button1 {
  border-radius: 4px;
  background-color: #f4511e;
  border: none;
  color: #FFFFFF;
  text-align: center;
  font-size: 24px;
  padding: 15px;
  width: 200px;
  transition: all 0.5s;
  cursor: pointer;
  margin: 5px;
  margin-left:70%
}

.button1 span {
  cursor: pointer;
  display: inline-block;
  position: relative;
  transition: 0.5s;
}

.button1 span:after {
  content: '\00bb';
  position: absolute;
  opacity: 0;
  top: 0;
  right: -20px;
  transition: 0.5s;
}

.button1:hover span {
  padding-right: 25px;
}

.button1:hover span:after {
  opacity: 1;
  right: 0;
}
  </style>