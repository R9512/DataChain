<script>
  import { Button, Checkbox } from 'svelte-mui/src';
  import 'focus-visible';
  import Switch from "svelte-switch";

  let checkedValue = true;

  function handleChange(e) {
    const { checked } = e.detail;
    checkedValue = checked;
  }
  export let name;
    // optional import focus-visible polyfill only once
    

    let checked = true;
</script>

<h1>Hello {name}!</h1>

<Checkbox bind:checked>Checkbox</Checkbox>

<p>Checkbox is <strong>{checked ? 'checked' : 'unchecked'}</strong></p>

<Button
    outlined
    shaped
    color="Red"
    on:click={() => { checked = !checked }}
>
    Inverse
</Button>
<h1>Simple usage</h1>
Switch with default style
<Switch on:change={handleChange} checked={checkedValue} />
<br />
The switch is {checkedValue ? 'on' : 'off'}.

<style>
    h1 {
        color: purple;
    }
</style>
