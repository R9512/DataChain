<script>
    import { metatags } from "@roxi/routify";
    import { params } from "@roxi/routify"
    import { onMount } from "svelte";    
    import Tags from "../../components/tags.svelte"
    import Navbar from "../../components/navbar.svelte";
    let user_id = $params.model_id;
    
    let title = "Sairam"
    let desc = ""
    let schema = ""
    let s = ""
    let attributes = []
    onMount(async function () 
  {
    const endpoint = "http://localhost:3000/model?id="+user_id
    const response = await fetch(endpoint);
    const data1 = (await response.json()).output;
    
    const data = JSON.parse(data1)
    title = data['title']
    desc = data['desc']
    s = data['tags'].split(',')
    schema = JSON.parse(data['schema'])
    let temp
    const base = document.getElementById('inputholder');
    for(let x in schema)
    {
        if(x=="output")
            break
        temp = document.getElementById('base').cloneNode(true)
        temp.style.display = ""
        temp.children[0].innerHTML = x+"-"+schema[x]
        temp.children[1].type = "string"
        temp.children[1].id = x
        base.append(temp)
        attributes.push(x)

    }
  });

  const sairam = async () => {
        
        
        let formdata = new FormData()
        
        /*for(var x = 0;x<attributes.length;x++)
        {
            formdata.append(attributes[x],document.getElementById(attributes[x]).value)
        }*/
        formdata.append("input","sairam7082")
        console.log(formdata)
        let res = await fetch('http://localhost:3000/model', {
                method: 'POST',
          mode: 'cors', 
        cache: 'no-cache', 
        credentials: 'same-origin',
        headers: {'Content-Type': 'application/json'},
        redirect: 'follow',
        referrerPolicy: 'no-referrer',
        body: JSON.stringify({
              
              
              "input":document.getElementById(attributes[0]).value,
              "modid":user_id
    
            }) 
            })

          
          return(res.json())
          
      };
  function predictor()
  {
    sairam().then(data=>{
        alert("Predition is:"+data.output)
      })
  }

</script>
<Navbar/>
<div class="cont">
    <h1 style="margin-left: 30%;">Model Details</h1>
    <h3 style="margin-left: 30%;">Title:{title}</h3>
    <h3 style="margin-left: 30%;">Description:</h3>
    <div style="margin-left: 30%;width:60%">
        <p>{desc}</p>
    </div>
    <h3 style="margin-left: 30%;">Tags:</h3>
    <div style="margin-left:30%;width:50%">

    {#if s === undefined}
    Loading Character Name...
  {:else}
    {#each s as models}
    <Tags tagname = {models}/>
    {/each}
        
        
  {/if}

  <div style="margin-left: 0%;display:none" id ="base">
    <h4>Attribute Name - Type</h4><input type="text"/>

  </div>
    </div>
    <h3 style="margin-left: 30%;">Input:</h3>

    <div style="margin-left:30%;width:50%" id = "inputholder">

        </div>
    
<button class="button1" on:click={predictor}><span>Predict</span></button>
        <h3 style="margin-left: 30%;">Output:{user_id}</h3>
    </div>
    
<style>
.cont
{
  background-color: #f5f5f5;
  margin-left: 25%;
  width: 50%;
}
.button1 {
  border-radius: 4px;
  background-color: #f4511e;
  border: none;
  color: #FFFFFF;
  text-align: center;
  font-size: 18px;
  padding: 10px;
  width: 130px;
  transition: all 0.5s;
  cursor: pointer;
  margin: 5px;
  margin-left:70%
}

.button1 span {
  cursor: pointer;
  display: inline-block;
  position: relative;
  transition: 0.5s;
}

.button1 span:after {
  content: '\00bb';
  position: absolute;
  opacity: 0;
  top: 0;
  right: -20px;
  transition: 0.5s;
}

.button1:hover span {
  padding-right: 25px;
}

.button1:hover span:after {
  opacity: 1;
  right: 0;
}
</style>
