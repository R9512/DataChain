<script>
  import Navbar from "../components/navbar.svelte";
  import { onMount } from "svelte";
  import { scale }  from "svelte/transition";
  import Switch from "svelte-switch";
  import Step from "../components/step.svelte"
  let answer = Array(15).fill(false)
  let curentn = 0
  let probval = [0,0,0]
  onMount(async function () 
  {
  });
  function handleChange(e) 
  {
    const { checked } = e.detail;
    alert(e.id)
     answer[0] = checked;
  }
  function sairam(val)
  {
    curentn+=val;
    if(curentn>2 )
      curentn%=3
    if(curentn<0)
      curentn=2
    
  }
  function swami()
  {
    probval = [0,0,0]
    let sum = 1
    for(var x=0;x<answer.length;x++)
      if(answer[x])
        {probval[Math.floor(x/5)]+=1;sum+=1}
    var temp = document.getElementsByClassName("pro")
    for(var x =0;x<probval.length;x++)
      {
        probval[x]/=sum; // 6.7
        probval[x]=Math.floor(probval[x]*100)
        temp[x].style.width = ''+probval[x]+"%"
      }
  }
</script>

<Navbar />
<div class="cont" >
  <div style="margin-left: 20%;"><Step value=0/></div>
  <h2 style="padding-left: 30%;">Learning Method Chooser</h2>

  {#if curentn==0}
  <div class="q" in:scale  >
  <table >
    <tr>
      <td><span style="padding-right: 50px;font-size:20px">- Is the data dynamic in nature? </span></td>
      <td><Switch on:change="{() => {answer[0] =!answer[0];handleChange;swami()} }"  checked={answer[0]}  height = 20 width=80></Switch></td>
    </tr>
    <tr>
      <td><span style="padding-right: 50px;font-size:20px">- Small amount of data is availble? </span></td>
      <td><Switch on:change="{() => {answer[1] =!answer[1];handleChange;swami()} }"  checked={answer[1]}  height = 20 width=80></Switch></td>
    </tr>
    <tr>
      <td><span style="padding-right: 50px;font-size:20px">- Should the model should update itself in real time? </span></td>
      <td><Switch on:change="{() => {answer[2] =!answer[2];handleChange;swami()} }"  checked={answer[2]}  height = 20 width=80></Switch></td>
    </tr>
    <tr>
      <td><span style="padding-right: 50px;font-size:20px">- Should the model handle the constant stream of data? </span></td>
      <td><Switch on:change="{() => {answer[3] =!answer[3];handleChange;swami()} }"  checked={answer[3]}  height = 20 width=80></Switch></td>
    </tr>
    <tr>
      <td><span style="padding-right: 50px;font-size:20px">- Computaionlly and economically Effective at the cost of performance? </span></td>
      <td><Switch on:change="{() => {answer[4] =!answer[4];handleChange;swami()} }"  checked={answer[4]}  height = 20 width=80></Switch></td>
    </tr>
  </table>
</div>
{/if}
{#if curentn==1}
<div class="q" in:scale > 
  <table >
    <tr>
      <td><span style="padding-right: 50px;font-size:20px">- The preditor varaible is fixed i.e static in nature?
      </span></td>
      <td><Switch on:change="{() => {answer[5] =!answer[5]; handleChange;swami()} }"  checked={answer[5]}  height = 20 width=80></Switch></td>
    </tr>
    <tr>
      <td><span style="padding-right: 50px;font-size:20px">- Moderate amount of data is available?</span></td>
      <td><Switch on:change="{() => {answer[6] =!answer[6];handleChange;swami()} }"  checked={answer[6]}  height = 20 width=80></Switch></td>
    </tr>
    <tr>
      <td><span style="padding-right: 50px;font-size:20px">- Should the model be updated frequently(Say once in a week)? </span></td>
      <td><Switch on:change="{() => {answer[7] =!answer[7];handleChange;swami()} }"  checked={answer[7]}  height = 20 width=80></Switch></td>
    </tr>
    <tr>
      <td><span style="padding-right: 50px;font-size:20px">- Is the dataset is already available and static in nature? </span></td>
      <td><Switch on:change="{() => {answer[8] =!answer[8];handleChange;swami()} }"  checked={answer[8]}  height = 20 width=80></Switch></td>
    </tr>
    <tr>
      <td><span style="padding-right: 50px;font-size:20px">- Do you prefer batch predictions over single record predictions? </span></td>
      <td><Switch on:change="{() => {answer[9] =!answer[9];handleChange;swami()} }"  checked={answer[9]}  height = 20 width=80></Switch></td>
    </tr>
  </table>
</div>
{/if}
{#if curentn==2}
<div class="q" in:scale >
  <table >
    <tr>
      <td><span style="padding-right: 50px;font-size:20px">
        - Is the data has very high number of dimensions?(  >50)
      </span></td>
      <td><Switch on:change="{() => {answer[10] =!answer[10];handleChange;swami()}}"  checked={answer[10]}  height = 20 width=80></Switch></td>
    </tr>
    <tr>
      <td><span style="padding-right: 50px;font-size:20px">
        - Do you prefer deplyoment of the neural network?</span></td>
      <td><Switch on:change="{() => {answer[11] =!answer[11];handleChange;swami()} }"  checked={answer[11]}  height = 20 width=80></Switch></td>
    </tr>
    <tr>
      <td><span style="padding-right: 50px;font-size:20px">
        - Is huge amount of data is already avaible?</span></td>
      <td><Switch on:change="{() => {answer[12] =!answer[12];handleChange;swami()} }"  checked={answer[12]}  height = 20 width=80></Switch></td>
    </tr>
    <tr>
      <td><span style="padding-right: 50px;font-size:20px">- Is the predictor varible is fixed? </span></td>
      <td><Switch on:change="{() => {answer[13] =!answer[13];handleChange;swami()} }"  checked={answer[13]}  height = 20 width=80></Switch></td>
    </tr>
    <tr>
      <td><span style="padding-right: 50px;font-size:20px">
        - Do you prefer performance over cost?</span></td>
      <td><Switch on:change="{() => {answer[14] =!answer[14];handleChange;swami()} }"  checked={answer[14]}  height = 20 width=80></Switch></td>
    </tr>
  </table>
</div>

{/if}
<br>
<button type="button" id="nextBtn" on:click={()=>sairam(-1)} >Previous</button>
<button type="button" style="margin-left: 75%;" id="nextBtn" on:click={()=>sairam(1)}>Next</button>
<h3>The learning method that suites your requirement is:</h3>
<div>
<h4>Online Learning:</h4>
<div id="myProgress"><div id="myBar" style="background-color: #04AA6D;;"class="pro"><div style="font-size: 20px;color:white;padding-top:3px;padding-left:5px">{probval[0]}%</div></div></div>

<h4>Machine Learning:</h4>
<div id="myProgress"><div id="myBar"  style="background-color: #042baa;" class="pro"><div style="font-size: 20px;color:white;padding-top:3px;padding-left:5px">{probval[1]}%</div></div></div>


<h4>Deep Learning:</h4>
<div id="myProgress"><div id="myBar"   class="pro"><div style="font-size: 20px;color:white;padding-top:3px;padding-left:5px">{probval[2]}%</div></div></div>

</div>
</div>
<style>
  #myProgress {
  width: 50%;
  background-color: #ddd;
  transition-duration: 0.2s;
  margin-left: 200px;
}
h4
{
  margin-left: 100px;
}

#myBar {
  width: 1%;
  height: 30px;
  background-color:#f8e42d;

  transition-duration: 0.2s;
}
  .cont 
  {
    background-color: #f5f5f5;
    margin-left: 30%;
    width: 40%;
    border-radius: 10px;
  }
  table 
  {
        border-collapse: separate;
        border-spacing: 0 15px;
        align-items: center;
        margin-left: 05%;
  }
      td 
  {
        text-align: left;
        border-bottom: 1px solid black;
        padding: 5px;
   }
    
    .q
    {
      background-color: #DDD;
      min-height: 300px;
      max-height: 300px;

    }
    button {
  background-color: #f4511e;
  color: #ffffff;
  border: none;
  padding: 10px 20px;
  font-size: 17px;
  cursor: pointer;
  border-radius: 5px;
}
</style>
