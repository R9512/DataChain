<script>
//The idea is to implemetn  the smart contract stuff
import {ethers} from "ethers"
import Hello from "../contract/Hello"
const contractabi =[
    {
      "inputs": [
        {
          "internalType": "string",
          "name": "_message",
          "type": "string"
        }
      ],
      "stateMutability": "nonpayable",
      "type": "constructor"
    },
    {
      "inputs": [],
      "name": "message",
      "outputs": [
        {
          "internalType": "string",
          "name": "",
          "type": "string"
        }
      ],
      "stateMutability": "view",
      "type": "function",
      "constant": true
    },
    {
      "inputs": [],
      "name": "hello",
      "outputs": [
        {
          "internalType": "string",
          "name": "",
          "type": "string"
        }
      ],
      "stateMutability": "view",
      "type": "function",
      "constant": true
    },
    {
      "inputs": [
        {
          "internalType": "string",
          "name": "_message",
          "type": "string"
        }
      ],
      "name": "sethello",
      "outputs": [],
      "stateMutability": "payable",
      "type": "function",
      "payable": true
    }
  ]



const address = "0x68C9e4E0900935733AebE1C34483AD605F462daB"

async function sairam()
{

  alert("From Sairam")
  const provider = new ethers.providers.Web3Provider(window.ethereum)
  /*const contract1 = new ethers.Contract(address, contractabi, provider);
  const message = await contract1.message()
  return(message.toString())*/
  const signer = provider.getSigner()
  const contract = new ethers.Contract(address,contractabi,signer)
  const txResponse = await contract.sethello("Hello from The Smart Contract....")
  const txReceipt = await txResponse.wait()
  const value = await contract.message()
  return(value.toString())

}
function fun()
    {
      alert("From Func")
      sairam().then(data=>{
        alert(data)
      })
    }
</script>
<h1>Om Sri Sairam</h1>
<button on:click={fun}>Sairam</button>
<style>

</style>