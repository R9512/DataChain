
<script>
  import 'boxicons'
  import Dashboardcard from '../components/dashboardcard.svelte';
  import Tempcard from "../components/tempcard.svelte";
  import { onMount } from "svelte";
  import { goto } from '@roxi/routify'
  import { beforeUpdate} from 'svelte';
  import { Sidepanel } from 'svelte-mui';
  import { Menu, Menuitem, Button} from 'svelte-mui';
  import Footer from "../components/footer.svelte";
  import {userd} from "./stores"
  let values = {}
  export let rightVisible = false;
  let udetails = ""

  beforeUpdate(async function()
  {
  userd.subscribe(value => {udetails = value});
  
  console.log(udetails)
    //if(udetails==0)
        //$goto('../usernotfound')
  })
  onMount(async function () 
  {
    
  const endpoint = "http://127.0.0.1:3000/jsairam"
  const response = await fetch(endpoint);
  const data = await response.json();
  values = data
  values.br = Number((data.br).toFixed(3))
  values.bt = Number((data.bt).toFixed(3))
  values.hr/= 1000000000000

  values.hr = Number((values.hr).toFixed(3))

});

function swami()
{
  rightVisible=true
}
  
  </script>

<div id="main" >
  <table border=0>
    <tr>
      <td width=90000%> 

        <span style="font-size:30px;cursor:pointer" on:click={swami}>&#9776; </span>
        <Sidepanel  bind:visible={rightVisible}>
          <div class="logo" style="padding-left: 1rem;"><h3 style = " color:#f4511e;padding-left:20%">DataChain</h3></div>
          <a href="/new0">New</a>
          <a href="/modelstore">Model Store</a>
          <a href="/datastore">Data Store</a>
          <a href="/mymodels">My Models</a>
      </Sidepanel>
      </td>
      <td>
        <Menu origin="top right">
          <div slot="activator">
              <Button color="white" width=25 ripple={true}>  <span class="dot"></span> </Button>
          </div>
      
          <Menuitem >Refresh</Menuitem>
          <Menuitem >Send feedback</Menuitem>
          <Menuitem >Settings</Menuitem>
          <Menuitem >Help</Menuitem>
          <Menuitem >Sign In</Menuitem>
          <hr />
      </Menu>
      </td>
    </tr>
  </table>
  <div class="grid-container">
    <Tempcard name="Block Number" color="#ef4444" text="Each New block is created for new bunch transactions to be entered into and validated.Latest block number that is mined" icon = "calculator" value={values.bn}/>
    <Tempcard name="Block Reward" color="#f97316" text="Bitcoin block rewards are new bitcoins awarded to cryptocurrency miners for being the first to solve a complex math problem and creating a new block of verified transactions." icon = "gift" value={values.br}/>  
    <Tempcard name="Block Time" color= "#ec4899" text="A block is verified by miners, who compete against each other to verify the transactions and solve the hash, which creates another block." icon = "timer" value={values.bt}/>
    <Tempcard name="Price" color ="#10b981" text="Real Time Ether value in US Dollars" icon = "dollar" value={values.price}/>
    <Tempcard name="HashRate" color="#4895ef" text="Hashrate reflects the performance of mining hardware.It is expressed in Terra Hashes per second" icon = "hash" value={values.hr}/>
    <Tempcard name="Ethers Mined" text=" Ether is a form of payment for network participants to execute their requested operations on the network." icon = "coin-stack" value={values.tc}/>
  </div>
<table style="width:100%;display:none">
  <tr>
    <td><Dashboardcard name="Block Number" text="Blocks are data structures within the blockchain database, where transaction data in a cryptocurrency blockchain are permanently recorded. A block records some or all of the most recent transactions not yet validated by the network. Once the data are validated, the block is closed. Then, a new block is created for new transactions to be entered into and validated.Latest block number that is mined" icon = "calculator" value={values.bn}/></td>

    <td><Dashboardcard name="Block Reward" text="Bitcoin block rewards are new bitcoins awarded to cryptocurrency miners for being the first to solve a complex math problem and creating a new block of verified bitcoin transactions. The miners use networks of computers to do this, and every time a new block is created it is verified by all the other competing miners. Then a new math problem is introduced and the miners start over. " icon = "gift" value={values.br}/></td>

    <td><Dashboardcard name="Block Time" text="

      Block time is the length of time it takes to create a new block in a cryptocurrency blockchain. A block is verified by miners, who compete against each other to verify the transactions and solve the hash, which creates another block.Under the proof-of-work consensus mechanism, cryptocurrency is rewarded for solving a block's hash and creating a new block.Time taken to create a new block expressed in seconds" icon = "timer" value={values.bt}/></td>

    <td><Dashboardcard name="Price" text="Real Time Ether value in US Dollars" icon = "dollar" value={values.price}/></td>
  </tr>
  <tr style="padding-left:20%">
    <td></td>
    <td><Dashboardcard name="HashRate" text="Hashrate reflects the performance of mining hardware. It is measured in solutions per second. A solution in the Ethereum network is called a hash, or simply h. Mining performance is measured in h/s (hashes per second).Here it is expressed in Terra Hashes" icon = "hash" value={values.hr}/></td>

    <td><Dashboardcard name="Ethers Mined" text="Ether is the transactional token that facilitates operations on the Ethereum network. All of the programs and services linked with the Ethereum network require computing power (and that computing power is not free). Ether is a form of payment for network participants to execute their requested operations on the network. Total number of Ether mined." icon = "coin-stack" value={values.tc}/></td>

    
  </tr>
</table>
<table>
  <tr>

  </tr>
</table>

<div class="grid-container" style="background-color: white;">
  <div class="grid-item">
    <div id="rcorners1" style="background-color:#ff0282;">
      <box-icon name='leaf'type = "logo" color="white" animation="tada-hover" size="60px" style="float: left;"></box-icon>
      <span style="font-size: 35px;font-weight:bold">Incremental Learning</span>
      
     <p>Incremental learning is a machine learning paradigm where the learning process takes place whenever new example emerge and adjusts what has been learned according to the new example.</p> 
      <p>Pros:</p>
      <ul>
        <li>Massive learning</li>

        <li>Lifetime memories</li>
      </ul> 

      <p>Cons:</p>
      <ul >
        <li>The model tries to span the availabe amount of data which can hinder the performance
        </li>

      </ul> 
      Python Module Used:River
    </div>
  </div>
  <div class="grid-item">

    <div id="rcorners1" style="background-color: #1e12ff;">
      
      <box-icon name='book-reader' type = "logo" color="white" animation="tada-hover" size="60px" style="float: left;"></box-icon><br>
     <span style="font-size: 35px;font-weight:bold">Conventional Learning</span> 
      <p>Machine learning is a branch of artificial intelligence (AI) and computer science which focuses on the use of data and algorithms to imitate the way that humans learn, gradually improving its accuracy.
      </p> 
      <p>Pros:</p>
      <ul>
        
        <li>Easily identifies trends and patterns.</li>

        <li>Handling multi-dimensional and multi-variety data.</li>
        <li> Continuous Improvement        </li>
      </ul> 

      <p>Cons:</p>
      <ul >
       

        <li>Requires massive data sets that are inclusive/unbiased, and of good quality to train on</li>
        <li>Machine Learning is autonomous but highly susceptible to errors</li>

      </ul> 
      Python Module Used:Scikit Learn
    
    </div>
  </div>
  <div class="grid-item">

    <div id="rcorners1"style="background-color: #00EA4A;">
      <box-icon name='search-alt-2' type = "logo" color="white" animation="tada-hover" size="60px" style="float: left;"></box-icon>
      <span style="font-size: 35px;font-weight:bold">Deep Learning</span>
        <p>Deep learning is a subset of machine learning, which is essentially a neural network with three or more layers. These neural networks attempt to simulate the behavior of the human brain—albeit far from matching its ability—allowing it to “learn” from large amounts of data. 
        </p> 
        <p>Pros:</p>
        <ul>

          <li>Maximal utilization of unstructured dat</li>
  
          <li>Deep learning algorithms are capable of learning without guidelines, eliminating the need for labeling the data.</li>
          </ul> 
  
        <p>Cons:</p>
        <ul >
               

  
          <li>Deep learning algorithm requires massive amounts of data to get trained</li>
          <li>Involves a lot of computations</li>
          <li>Deep learning requires numerous machines and expensive GPUs to work.</li>
  
        </ul> 
        Python Module Used:Tensor Flow
      
    </div>
  </div>  
</div>
<div></div>
<h3 style="align:center">Terms And Conditions Goes Here... Still Work In Progress</h3>
<div id="rcorners1" style="background-color:#ecf0f6;width:100%">
  <div style="padding-left: 20px;">
    <h1>Do's</h1>
    <ul style="font-size: 20px;">
      <li>Always Use the Platform for the Ethical Uses of the AI only. By using the service, user agrees to the Ethical AI terms and Conditions of NVIDIA Licinece Agreement</li>
      <li>Keep changing the password once in a two months</li>
      <li>Install the metamask from the trusted sites like the Chrome Webstore or Firefox Extenstions</li>
      <li>Always maintain a copy of the backup phrase of the Metamask Crypto Wallet</li>
      <li>While contributing to the data ensure that no personal information is revealed</li>
      <li>While finalaizing the deal always double cross the details with the Centry Record</li>
      <li>Report a model to the Datachain team which contributes or participates in the harm of any creature</li>
    </ul>
    <hr>
    <h1>Dont's</h1>

  </div>

</div>
</div>
<Footer/>
//#ecf0f6;

<style>
  #rcorners1 
{
  border-radius: 25px;
  background: #73AD21;
  padding: 0px; 
  width: 580px;
  height: 800px;  
}
.grid-container {
  color:whitesmoke;
  display: grid;
  grid-template-columns: auto auto auto;
  padding: 10px;
}
.grid-item {
  padding: 20px;
  font-size: 25px;
}

a {
  padding: 8px 8px 8px 8px;
  text-decoration: none;
  font-size: 25px;
  color: #f4511e;
  display: block;
  transition: 0.3s;
}
a:hover {
  background-color: #f4511e;
  color: white;
}
.dot {
  height: 35px;
  width: 35px;
  background-color: #f4511e;
  border-radius: 50%;
  display: inline-block;
}
li
{
padding: 1%;
}
.grid-container {
  display: grid;
  grid-template-columns: auto auto auto;
  background-color: #ef4444;
  padding: 10px;
}
</style>
  