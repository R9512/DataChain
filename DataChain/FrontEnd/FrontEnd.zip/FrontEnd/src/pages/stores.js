import { writable } from 'svelte/store';

export const countdetails = writable(0);
export const ethval = writable(56)
export const model =writable(0)
export const learning =writable(0)
export const userd=writable(0)