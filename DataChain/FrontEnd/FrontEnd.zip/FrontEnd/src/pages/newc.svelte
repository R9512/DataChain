<script>
  import Navbar from "../components/navbar.svelte";
  import { beforeUpdate } from "svelte";
  import { goto } from '@roxi/routify'
  beforeUpdate(async function()
  {
    if(sessionStorage.getItem("UserName")===null)
        console.log("Swami")//$goto('../usernotfound')
  })
  let count = 0
    function attributeadder()
  {
    const ele = document.getElementById("base")
    count+=1
    let newel = ele.cloneNode(true)
    newel.style = ""
    document.getElementById("attributes").appendChild(newel)
  }
  const sairam = async () => {
        
           
        let formdata = new FormData()
        const input = document.querySelector('input[type="file"]');
        const file = input.files[0];
        const collection = document.getElementsByClassName("attributename")
        const collection1 = document.getElementsByClassName("attributetype")
        let schema = {}
        for (let i = 1; i < collection.length; i++) 
           schema[collection[i].value] = collection1[i].value

        formdata.append('title',document.getElementById("title").value)  
        formdata.append('desc',document.getElementById("desc").value)
        formdata.append('tags',document.getElementById("tags").value)
        formdata.append('hp1',56)
        formdata.append("model",file)
        formdata.append("schema",JSON.stringify(schema))
        console.log(formdata.schema)
        const options = {
          method: 'POST',
          mode: 'cors', 
          body: formdata,
          headers: { 'Content-Type': 'multipart/form-data', }
          };
          delete options.headers['Content-Type'];
        let res = await fetch('http://localhost:3000/newmod', options)

          
          return(res.json())
          
      };
  function creator()
  {
    sairam().then(data=>{
        alert(data.output)
      })
  }
</script>
<Navbar/>
<div class="round2">
  <h1 style=" text-align: center;">Model Creation</h1>
<div class="cont">

  <h3 style="margin-left: 30%;">Title:</h3>
  <input id="title" style="margin-left: 35%;" type="text" rows="4" cols="35"/>
  <br>
  <h3 style="margin-left: 30%;">Model Description:</h3>
  <textarea id="desc" style="resize: none;margin-left: 35%;" rows="4" cols="35"/>
  <br>

  <h3 style="margin-left: 30%;">Filter-Pickle File:</h3>
  <input type="file" style="margin-left: 35%;" id="model"/>
  <br>
  
  <h3 style="margin-left: 30%;">Tags:</h3><p style="margin-left: 35%;">(Seperated by comma)</p>
  <textarea id="tags" style="resize: none;margin-left: 35%;" rows="2" cols="35"/>
  <br>

  <h3 style="margin-left: 30%;">Hyper Parameter1:</h3>
  <input type="range" min="1" max="100" value="50" style="margin-left: 35%;" class="slider" id="myRange">
  <br>
  
  <button class="button" on:click={attributeadder}>Add Attribute</button>
  <div id="base" style="display: none;">
    <table>
      <tr>
        <th>Enter a Field Name</th>
        <th>Datatype</th>
      </tr>
      <tr>
        <td><input class="attributename" type="text"/></td>
        <td>
          <select class="attributetype" name="cars" id="cars">
          <option value="int">Integer</option>
          <option value="float">Float</option>
          <option value="bool">Boolean</option>
          <option value="str">String</option>
        </select>
      </td>
       </tr>
      
    </table> 
  </div>
  <div id = "attributes" style="margin-left: 35%;">

</div>

<button class="button1" on:click={creator}><span>Create </span></button>
</div>


</div>
<style>

.round2 
{
  border: 2px solid black;
  border-radius: 8px;
  padding: 5px;
}
.cont
{
  background-color: #f5f5f5;
  margin-left: 25%;
  width: 50%;
}
.button {
  background-color: #4CAF50;
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
  margin-left: 45%;
}
.button1 {
  border-radius: 4px;
  background-color: #f4511e;
  border: none;
  color: #FFFFFF;
  text-align: center;
  font-size: 24px;
  padding: 15px;
  width: 200px;
  transition: all 0.5s;
  cursor: pointer;
  margin: 5px;
  margin-left:70%
}

.button1 span {
  cursor: pointer;
  display: inline-block;
  position: relative;
  transition: 0.5s;
}

.button1 span:after {
  content: '\00bb';
  position: absolute;
  opacity: 0;
  top: 0;
  right: -20px;
  transition: 0.5s;
}

.button1:hover span {
  padding-right: 25px;
}

.button1:hover span:after {
  opacity: 1;
  right: 0;
}
</style>