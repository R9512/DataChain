<script>
    import Tempcard from "../components/tempcard.svelte";
</script>
<Tempcard name="Block Number" color="red" text="Blocks are data structures within the blockchain database, where transaction data in a cryptocurrency blockchain are permanently recorded. A block records some or all of the most recent transactions not yet validated by the network. Once the data are validated, the block is closed. Then, a new block is created for new transactions to be entered into and validated.Latest block number that is mined" icon = "calculator" value={56}/>