<script>
    import Modelcard from "../components/modelcard.svelte" 
    import Navbar from "../components/navbar.svelte";
    import { onMount } from "svelte";
    let data
    let temp=[]
    onMount(async function () 
  {
    const endpoint = "http://localhost:3000/predict"
    const response = await fetch(endpoint);
    const data1 = (await response.json()).output;
    for(var a =0;a<data1.length;a++)
        {temp.push(JSON.parse(data1[a]));
        }
    data = temp
  });
</script>
<main>
<Navbar/>
<div class="grid-container">
    {#if data === undefined}
        Loading Character Name...
    {:else}
        {#each data as models}
        <div class="grid-item">
        <Modelcard title = {models.title}, tags={models.tags}, link={models.modelid} vpath={"contr"}/>
        </div>
        {/each}
            
            
    {/if}
</div>
</main>
<style>
.grid-container {
  display: grid;
  grid-template-columns: auto auto auto;
  
}
.grid-item {
  
  text-align: center;
}
</style>